<?php
/*absolute path to project*/
define('ABSOLUTE_PATH', dirname(__FILE__).'/');

/*Current php framwork version*/
define('FRAME_WORK_PATH', 'fw_20/');

/*Framework configuration*/
require_once(FRAME_WORK_PATH.'Config.php');

/*current db server constants*/
//require_once(ABSOLUTE_PATH.'../../postgres_srv.php');
define('DB_SERVER','crm.plpl.ru');
define('DB_SERVER_MASTER','crm.plpl.ru');
define('SESS_DB_SERVER','crm.plpl.ru');

/*Server unique configuration*/
require_once('Config.uniq.php');

/*Current version for js*/
require_once('version.php');

//********************************************************************************
/*Db connection constants*/
define('DB_NAME', 'polimerplast');
define('DB_USER', 'polimerplast');
define('DB_PASSWORD', 'lskfmpcmJMUH');

/*Application constants*/
define('APP_NAME', 'Polimerplast');
define('DEBUG', TRUE);
define('TECH_EMAIL', 'katren_shd@rambler.ru');

/*Default View*/
define('DEF_VIEW', 'ViewBase');

//********************************************************************************

//SMS service
define('SMS_LOGIN', 'Eurobeton');
define('SMS_PWD', '1zxcvfdsa2');
define('SMS_SIGN', 'Eurobeton');// TEST-SMS
define('SMS_ACTIVE', TRUE);
define('SMS_TEST', TRUE);

/*Default user password*/
define('DEF_USER_PWD', '123');

/*host with 1c server*/
define('HOST_1C', '185.54.238.178');
define('PORT_1C', '8080');

/*host with OpenStreetMap routing machine server*/
define('OSRM_HOST', '192.168.1.77');
define('OSRM_PORT', '5000');
define('OSRM_PROTOCOLE', 'http');

/*Email*/
define('EMAIL_FROM_ADDR', 'katrenplus@mail.ru');
define('EMAIL_FROM_NAME', 'Полимерпласт');

//SMTP
define('SMTP_HOST', 'smtp.mail.ru');
define('SMTP_USER', 'katrenplus@mail.ru');
define('SMTP_PWD', 'wimmdii171003');
define('SMTP_PORT', 465);

/*Yandex key for this host*/
define('YANDEX_KEY', 'AOqmiU0BAAAAAiumcgIAS5Sa-sZoVE66Vfk6dMDvRmMSOGcAAAAAAAAAAAAY4mKHCADcJhtoFOz0PciqXtbx0Q==');

/*Session expiration limit in seconds*/
define('SESSION_EXP_SEC', 300000);
define('AJAX_EXT_VIEW', NULL);

/*Building constants*/
define('BUILD_GROUP', 'andrey');
define('BUILD_FILE_PERMISSION', '0664');
define('BUILD_DIR_PERMISSION', '0775');

define('PROJECT_REPO_URL','192.168.1.77');
define('PROJECT_REPO_USER','proj-repo');
define('PROJECT_REPO_PWD','qwerty159753');

?>
