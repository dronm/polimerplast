<?php
require_once('Config.php');
require_once(FRAME_WORK_PATH.'cmd.php');
?>