<?php
echo (string) round(microtime(true) * 1000);
?>