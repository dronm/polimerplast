TRACK_CONSTANTS = {
	IMG_PATH:"img/",
	POINTER_IMGS: {
		blue:'pointer_blue.png',
		red:'pointer_red.png',
		green:'pointer_green.png'
	},
	STOP_IMGS: {
		blue:'dot_blue.png',
		red:'dot_red.png',
		green:'dot_green.png'
	},	
	DEF_THEME:"blue",
	FOUND_ZOOM:15,
	INI_ZOOM:10,
	//VEH_IMG:"img/pointer_blue.png",
	MARKER_IMGS:{
		blue:'marker-blue.png',
		red:'marker-red.png',
		green:'marker-green.png'		
	}
}
