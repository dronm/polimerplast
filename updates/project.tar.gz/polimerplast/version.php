<?php
		define('VERSION','1.0022');
		?>