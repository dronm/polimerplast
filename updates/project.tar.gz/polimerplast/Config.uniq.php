<?php
/*Contstants unique to this server
*/

//host for js
define('BASE_PATH','http://localhost/polimerplast/');

?>
