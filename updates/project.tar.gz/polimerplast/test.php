<?php
$pathArray = explode(PATH_SEPARATOR, get_include_path());
var_dump($pathArray);
?>
